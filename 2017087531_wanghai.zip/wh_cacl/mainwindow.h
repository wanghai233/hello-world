#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void takeResult();

private slots:
    void on_okButton_clicked();
    void on_comboBox_currentIndexChanged(const QString &text);
    void on_doubleSpinBox_valueChanged(double value);
    void on_doubleSpinBox_2_valueChanged(double value);

private:
    Ui::MainWindow *ui;
    QString m_strOperator;
    double m_dbValue1;
    double m_dbValue2;
};

#endif // MAINWINDOW_H
