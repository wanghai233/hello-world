#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_strOperator("+"),
    m_dbValue1(0),
    m_dbValue2(0)
{
    ui->setupUi(this);
    QStringList list;
    list << "+" << "-" << "*" << "/";
    ui->comboBox->addItems(list);

    ui->doubleSpinBox->setValue(1.0);
    ui->doubleSpinBox_2->setValue(1.0);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::takeResult()
{
    double ret = 0;
    if (m_strOperator == "+")
    {
        ret = m_dbValue1 + m_dbValue2;
    }
    else if(m_strOperator == "-")
    {
        ret = m_dbValue1 - m_dbValue2;
    }
    else if (m_strOperator == "*")
    {
        ret = m_dbValue1 * m_dbValue2;
    }
    else
    {
        if (m_dbValue2 == 0
                || m_dbValue2 == 0.00)
        {
            ui->doubleSpinBox_2->setFocus();
            ui->lineEdit->setText("Error!");
            return;
        }
        ret = m_dbValue1 / m_dbValue2;
    }
    ui->lineEdit->setText(QString::number(ret));
}

void MainWindow::on_okButton_clicked()
{
    this->close();
}

void MainWindow::on_doubleSpinBox_valueChanged(double value)
{
    m_dbValue1 = value;
    m_dbValue2 = ui->doubleSpinBox_2->value();
    takeResult();
}

void MainWindow::on_doubleSpinBox_2_valueChanged(double value)
{
    m_dbValue1 = ui->doubleSpinBox->value();;
    m_dbValue2 = value;
    takeResult();
}

void MainWindow::on_comboBox_currentIndexChanged(const QString &text)
{
    m_strOperator = text;
    if (text == "/")
    {
        if (ui->doubleSpinBox_2->value()==0)
        {
            ui->doubleSpinBox_2->setValue(1.0);
            ui->doubleSpinBox_2->setFocus();
            return;
        }
    }
    takeResult();
}


