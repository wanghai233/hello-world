#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    QString makeColorString(const QColor &color, const QString type);
    void changeStytle();
private slots:
    void slot_timeOut();

    void on_pushButton_1_clicked();

    void on_pushButton_6_clicked();


private:
    Ui::MainWindow *ui;
    QTimer *m_pTimer;
    int m_nValue;
    bool m_bIsTime;
    int m_nFontSize;
    QColor m_font;
    QColor m_back;
};

#endif // MAINWINDOW_H
