/*
 * 按下crtl+r
 * 第一个界面设置底色
 * 第二个界面设置字色
 * creator：王海
 */
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTimer>
#include <QColorDialog>
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_pTimer(NULL),
    m_nValue(20),           //设置20秒倒计时
    m_bIsTime(false),
    m_nFontSize(40),        //标签字体设置成40像素高
    m_font(0,0,0),
    m_back(255,255,255)
{
    ui->setupUi(this);
    ui->lcdNumber->setDigitCount(2);
    ui->pushButton_6->setVisible(false);
    ui->spinBox->setValue(20);
    ui->lcdNumber->setStyleSheet(QString("font: %1pt;").arg(m_nFontSize));


    m_pTimer = new QTimer(this);
    connect(m_pTimer, SIGNAL(timeout()), this, SLOT(slot_timeOut()));

    ui->lcdNumber->setMaximumHeight(m_nFontSize);
    ui->lcdNumber->setMinimumHeight(m_nFontSize);

    QColorDialog color;
    QColor c1 = color.getRgba();
    m_back = c1;
    changeStytle();

    QColor c2 = color.getRgba();
    m_font = c2;
    changeStytle();
}

QString MainWindow::makeColorString(const QColor &color, const QString type)
{
    if(type == "RGBA") {
        return QString("rgba(%1, %2, %3, %4)")
                .arg(color.red())
                .arg(color.green())
                .arg(color.blue())
                .arg(color.alpha());
    }
    if(type == "RGB") {
        return QString("rgba(%1, %2, %3)")
                .arg(color.red())
                .arg(color.green())
                .arg(color.blue());
    }
    if(type == "HEX") {
        return QString().sprintf("#%1%02X%02X%02X",
                                 color.red(),
                                 color.green(),
                                 color.blue()).arg(color.alpha() != 255 ? QString().sprintf("%02X", color.alpha()) : QString());
    }

    return color.name();
}

void MainWindow::changeStytle()
{
    QString strFont = makeColorString(m_font,"RGB");
    QString strBack = makeColorString(m_back,"RGB");
    ui->lcdNumber->setStyleSheet(QString("color: %1; background-color: %2;").arg(strFont).arg(strBack));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::slot_timeOut()
{
    ui->lcdNumber->display(m_nValue);
    if (m_bIsTime)
    {
        if (m_nValue <= 0)
        {
            m_bIsTime = false;
            m_pTimer->stop();
            QMessageBox::warning(this, "timer", QObject::trUtf8("时间到!"));
        }
        m_nValue--;
    }


}

void MainWindow::on_pushButton_1_clicked()
{
    m_bIsTime = true;
    m_pTimer->start(1000);
    m_nValue = ui->spinBox->value();
    ui->lcdNumber->display(m_nValue);
    ui->pushButton_1->setVisible(!ui->pushButton_1->isVisible());
    ui->pushButton_6->setVisible(!ui->pushButton_6->isVisible());
}

void MainWindow::on_pushButton_6_clicked()
{
    QApplication::closeAllWindows();
}


