#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDialog>
#include <QSettings>
#include <QHBoxLayout>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QSettings settings("TestSetting.ini", QSettings::IniFormat);
    QString user = settings.value("test/user").toString();
    QString pass = settings.value("test/pass").toString();
    bool ischeck = settings.value("test/check").toBool();
    if ( ischeck == true)
    {
        ui->lineEdit->setText(user);
        ui->lineEdit_2->setText(pass);
        ui->checkBox->setChecked(ischeck);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_cancelButton_clicked()
{
    qApp->exit();
}

void MainWindow::on_okButton_clicked()
{
    QSettings settings("TestSetting.ini", QSettings::IniFormat);
    settings.beginGroup("test");
    settings.setValue("user", ui->lineEdit->text());
    settings.setValue("pass", ui->lineEdit_2->text());
    settings.setValue("check", ui->checkBox->isChecked());
    settings.endGroup();

    if ( ui->lineEdit->text() == "root" &&
         ui->lineEdit_2->text() == "123456")
    {
        this->setVisible(false);
        QDialog dlg;
        QHBoxLayout *mainLayout = new QHBoxLayout();
        mainLayout->setMargin(0);
        QLabel *tipLabel = new QLabel("PPMS电力多元化收费系统");
        tipLabel->setStyleSheet("QLabel{background-color: #22FFBB; color: red;  font: 24pt; padding: center; }");
        mainLayout->addWidget(tipLabel);
        dlg.resize(600, 480);
        dlg.setLayout(mainLayout);
        if (dlg.exec() == QDialog::Rejected)
        {
            qApp->exit();
        }
    }
    else
    {
        ui->lineEdit->setFocus();       
    }
}
